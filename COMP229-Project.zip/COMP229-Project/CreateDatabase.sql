CREATE DATABASE [ShalomLibrary] 
